package edu.ics111.h12;

import edu.ics111.h02.TextIO;

/**
 * Represents a PrintAnagrams. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 */
public class PrintAnagrams {

  /**
   * Asks the user for a word, then calls a method to print all possible anagrams of that word.
   * 
   * @param args Not Used
   */
  public static void main(String[] args) {
    System.out.println("Please input a word to get its anagrams: ");
    String word = TextIO.getlnWord();
    printAnagrams("", word);
  }


  /**
   * Recursively prints all of the possible anagrams for the word.
   * 
   * @param prefix The letters already used in the variation of the method.
   * @param word The remaining string yet to be used.
   */
  public static void printAnagrams(String prefix, String word) {
    if (word.length() == 1) {
      System.out.println(prefix + word);
    } else {
      for (int letterCount = 0; letterCount < word.length(); letterCount++) {
        String currentLetter = String.valueOf(word.charAt(letterCount));

        String remainingLetters = word.substring(0, letterCount) + word.substring(letterCount + 1);

        printAnagrams(prefix + currentLetter, remainingLetters);
      }
    }
  }

}
