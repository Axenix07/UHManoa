package edu.ics111.h06;

/**
 * Represents a HexadecimalAdditionQuiz. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 *
 */
public class HexadecimalAdditionQuiz {

  /**
   * Administers a basic hexadecimal addition quiz to the user.
   * 
   * @param args Not Used
   */
  public static void main(String[] args) {
    int[] firstNumbers = new int[10];
    int[] secondNumbers = new int[10];
    int[] correctAnswers = new int[10];
    int[] answers = new int[10];

    createQuiz(firstNumbers, secondNumbers, correctAnswers, answers);

    int numberCorrect = checkAnswers(firstNumbers, secondNumbers, correctAnswers, answers);
    System.out.printf("Score %d/100", (numberCorrect * 10));

  }


  /**
   * Checks if the inputed numbers are correct, and tracks the number of correct answers.
   * 
   * @param firstNumbers the array of numbers for the first operand.
   * @param secondNumbers the array of numbers for the second operand.
   * @param correctAnswers the array of numbers for the correct answers.
   * @param answers the array of numbers for the inputed answers.
   * @return returns the number of correct answers.
   */
  public static int checkAnswers(int[] firstNumbers, int[] secondNumbers, int[] correctAnswers,
      int[] answers) {
    int answerCount;
    int numberCorrect = 0;

    for (answerCount = 0; answerCount <= 9; answerCount++) {
      if (answers[answerCount] == correctAnswers[answerCount]) {
        System.out.printf("%2X + %2X = %2X (Correct)\n", firstNumbers[answerCount],
            secondNumbers[answerCount], answers[answerCount]);
        numberCorrect++;
      } else {
        System.out.printf("%2X + %2X = %2X (Incorrect)  The Correct answer is: %2X\n",
            firstNumbers[answerCount], secondNumbers[answerCount], answers[answerCount],
            correctAnswers[answerCount]);
      }
    }
    return numberCorrect;
  }


  /**
   * Method to fill the arrays for the quizzes.
   * 
   * @param firstNumbers created array for the first operand.
   * @param secondNumbers created array for the second operand.
   * @param correctAnswers created array for the correct answers
   * @param answers created array for the inputed answers.
   */
  public static void createQuiz(int[] firstNumbers, int[] secondNumbers, int[] correctAnswers,
      int[] answers) {
    int questionCount;
    for (questionCount = 0; questionCount <= 9; questionCount++) {
      firstNumbers[questionCount] = fillOperand();
      secondNumbers[questionCount] = fillOperand();
      correctAnswers[questionCount] = firstNumbers[questionCount] + secondNumbers[questionCount];

      System.out.printf("%2X + %2X = ", firstNumbers[questionCount], secondNumbers[questionCount]);
      answers[questionCount] = convertAnswer();
    }
  }


  /**
   * Converts answer in Hexadecimal to an Integer.
   * 
   * @return returns an the converted answer as an Integer.
   */
  public static int convertAnswer() {
    boolean keepAsking = true;
    int intAnswer = 0;
    String hex;

    while (keepAsking) {
      try {

        hex = TextIO.getlnWord();
        intAnswer = Integer.parseInt(hex, 16);
        keepAsking = false;

      } catch (Exception error) {
        System.out.print("Please input a valid hexadecimal number: ");
      }
    }

    return intAnswer;
  }


  /**
   * Creates a random number between 1 and 100 for one of the operands.
   * 
   * @return returns an Integer that works as one of the operands
   */
  public static int fillOperand() {
    return ((int) (Math.random() * 100) + 1);
  }

}
