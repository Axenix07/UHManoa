package edu.ics111.h01;

/**
 * Represents a TwentySidedDice.
 *
 * @author Austin Gardner
 *
 */
public class TwentySidedDice {

  /**
   * Outputs results for rolling 2 20 sided dice.
   *
   * @param args Not Used
   */
  public static void main(String[] args) {

    int firstDieResult = (int) (Math.random() * 20) + 1;
    int secondDieResult = (int) (Math.random() * 20) + 1;
    int total = firstDieResult + secondDieResult;

    System.out.println("The first die comes up " + firstDieResult);
    System.out.println("The second die comes up " + secondDieResult);
    System.out.println("Your total roll is " + total);
  }

}
