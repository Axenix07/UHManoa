package edu.ics111.h01;

/**
 * Represents a SixSidedDie.
 *
 * @author Austin Gardner
 *
 */
public class SixSidedDie {

  /**
   * Outputs results for rolling 2 6 sided dice.
   *
   * @param args Not used.
   */
  public static void main(String[] args) {

    int firstDieResult = (int) (Math.random() * 6) + 1;
    int secondDieResult = (int) (Math.random() * 6) + 1;
    int total = firstDieResult + secondDieResult;

    System.out.println("The first die comes up " + firstDieResult);
    System.out.println("The second die comes up " + secondDieResult);
    System.out.println("Your total roll is " + total);
  }

}
