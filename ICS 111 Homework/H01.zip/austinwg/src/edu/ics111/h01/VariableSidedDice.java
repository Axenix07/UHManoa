package edu.ics111.h01;

import java.util.Scanner;

/**
 * Represents a VariableSidedDice. Used Chatgpt and Stack Overflow for information on the scanner
 *
 * @author Austin Gardner
 *
 */
public class VariableSidedDice {

  /**
   * Asks user for the number of faces for the 2 dice, then outputs the result.
   *
   * @param args Not Used
   */
  public static void main(String[] args) {

    rollVariableDice();

  }


  /**
   * Asks user for the number of faces for the 2 dice, then outputs the result.
   */
  public static void rollVariableDice() {
    Scanner userInput = new Scanner(System.in);

    System.out.println("Input the number of faces for the dice (int only): ");

    if (userInput.hasNextInt()) {
      int faces = userInput.nextInt();

      int firstDieResult = (int) (Math.random() * faces) + 1;
      int secondDieResult = (int) (Math.random() * faces) + 1;
      int total = firstDieResult + secondDieResult;

      System.out.println("The first die comes up " + firstDieResult);
      System.out.println("The second die comes up " + secondDieResult);
      System.out.println("Your total roll is " + total);

      userInput.close();

    } else {
      System.out.println("Error because the input wasn't an integer");
      rollVariableDice();
    }
  }

}
