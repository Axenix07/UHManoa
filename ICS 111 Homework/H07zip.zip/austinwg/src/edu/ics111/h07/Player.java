package edu.ics111.h07;

import edu.ics111.h02.TextIO;

/**
 * Represents a Player.
 * 
 * @author Austin Gardner
 *
 */
public class Player {

  String name;
  int score = 0;

  public void resetScore() {
    score = 0;
  }


  /**
   * Creates a new Player.
   * 
   * @param playerName name of the player.
   */
  public Player(String playerName) {
    name = playerName;
  }


  /**
   * The method for a players turn.
   * 
   * @return The score gained over the turn
   */
  public int playerTurn() {

    int turnScore = 0;
    boolean turnOver = false;
    int newScore = 0;
    PairOfDice dice = new PairOfDice();

    while (!turnOver) {

      String hold;
      System.out.println("Do you want to hold? (y/n)");
      hold = TextIO.getlnString();
      while (!hold.equals("n") && !hold.equals("y")) {
        System.out.println("Please answer with just 'y' or 'n'");
        hold = TextIO.getlnString();
      }

      if (hold.equals("n")) {
        dice.rollDice();
        System.out.println("The roll was " + dice.dieOne + " and " + dice.dieTwo);
        if (dice.dieOne == 1 && dice.dieTwo == 1) {
          turnScore = 0;
          newScore = 0;
          System.out.println("Score: " + this.score);
          turnOver = true;
        } else if (dice.dieOne == 1 || dice.dieTwo == 1) {
          turnScore = 0;
          turnOver = true;
          newScore = score;
        } else if (dice.dieOne == dice.dieTwo) {
          turnScore += 2 * (dice.dieOne + dice.dieTwo);
          newScore = score + turnScore;
        } else {
          turnScore += dice.dieOne + dice.dieTwo;
          newScore = score + turnScore;
        }
        System.out.println("The score for the turn is: " + turnScore);
      } else {
        turnOver = true;
      }

    }

    return newScore;
  }
}
