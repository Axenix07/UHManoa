package edu.ics111.h07;

/**
 * Represents a PairOfDice.
 * 
 * @author Austin Gardner
 *
 */
public class PairOfDice {

  int dieOne;
  int dieTwo;

  /**
   * Rolls the two dice for the players.
   */
  public void rollDice() {
    dieOne = (int) (Math.random() * 6) + 1;
    dieTwo = (int) (Math.random() * 6) + 1;
  }
}
