package edu.ics111.h07;

import edu.ics111.h02.TextIO;

/**
 * Represents a TwoDicePigGame. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 *
 */
public class TwoDicePigGame {

  /**
   * Plays Two-Dice Pig.
   * 
   * @param args Not Used
   */
  public static void main(String[] args) {
    System.out.println("Input the number of players: ");
    int playerCount = TextIO.getlnInt();
    while (playerCount <= 0 || playerCount >= 11) {
      System.out.println("Please input a  number greater than 0 and less than 11.");
      playerCount = TextIO.getlnInt();
    }
    Player[] players = new Player[playerCount];
    boolean gameOver = false;

    for (int i = 0; i < playerCount; i++) {
      System.out.println("Enter the name for Player " + (i + 1));
      String playerName = TextIO.getlnString();
      players[i] = new Player(playerName);
    }

    while (!gameOver) {
      for (Player player : players) {
        System.out.println("It is " + player.name + "'s turn.");

        player.score = player.playerTurn();

        System.out.println(player.name + "'s score after the turn is: " + player.score);

        if (player.score >= 100) {
          gameOver = true;
          System.out.println(player.name + " Won!!!!");
        }
      }
    }

  }

}
