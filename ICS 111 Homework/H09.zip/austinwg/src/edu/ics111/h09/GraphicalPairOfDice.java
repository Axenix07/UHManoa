package edu.ics111.h09;

import edu.ics111.h07.PairOfDice;
import java.awt.Color;
import java.awt.Graphics;

/**
 * Represents a GraphicalPairOfDice. Used Chatgpt and Stack Overflow for help. Grabbed code from
 * exercise 6.3 in the textbook
 * 
 * @author Austin Gardner
 * 
 */

public class GraphicalPairOfDice extends PairOfDice {
  int graphicalDiceOne = 1;
  int graphicalDiceTwo = 1;

  /**
   * Rolls the dice. Overwrites old method to make the variables accessible
   */
  public void rollDice() {
    graphicalDiceOne = (int) (Math.random() * 6) + 1;
    graphicalDiceTwo = (int) (Math.random() * 6) + 1;
  }


  /**
   * Draws the given die at x and y.
   * 
   * @param g The Graphics context.
   * @param dieNum the number of the die either 1 or 2.
   * @param x the x location for the die.
   * @param y the y location for the die.
   * 
   */
  public void drawDie(Graphics g, int dieNum, int x, int y) {

    g.setColor(Color.white);
    g.fillRect(x, y, 35, 35);
    g.setColor(Color.black);
    g.drawRect(x, y, 34, 34);

    if (dieNum == 1) {
      if (graphicalDiceOne > 1) {
        g.fillOval(x + 3, y + 3, 9, 9);
      }
      if (graphicalDiceOne > 3) {
        g.fillOval(x + 23, y + 3, 9, 9);
      }
      if (graphicalDiceOne == 6) {
        g.fillOval(x + 3, y + 13, 9, 9);
      }
      if (graphicalDiceOne % 2 == 1) {
        g.fillOval(x + 13, y + 13, 9, 9);
      }
      if (graphicalDiceOne == 6) {
        g.fillOval(x + 23, y + 13, 9, 9);
      }
      if (graphicalDiceOne > 3) {
        g.fillOval(x + 3, y + 23, 9, 9);
      }
      if (graphicalDiceOne > 1) {
        g.fillOval(x + 23, y + 23, 9, 9);
      }
    } else {
      if (graphicalDiceTwo > 1) {
        g.fillOval(x + 3, y + 3, 9, 9);
      }
      if (graphicalDiceTwo > 3) {
        g.fillOval(x + 23, y + 3, 9, 9);
      }
      if (graphicalDiceTwo == 6) {
        g.fillOval(x + 3, y + 13, 9, 9);
      }
      if (graphicalDiceTwo % 2 == 1) {
        g.fillOval(x + 13, y + 13, 9, 9);
      }
      if (graphicalDiceTwo == 6) {
        g.fillOval(x + 23, y + 13, 9, 9);
      }
      if (graphicalDiceTwo > 3) {
        g.fillOval(x + 3, y + 23, 9, 9);
      }
      if (graphicalDiceTwo > 1) {
        g.fillOval(x + 23, y + 23, 9, 9);
      }
    }

  }

}