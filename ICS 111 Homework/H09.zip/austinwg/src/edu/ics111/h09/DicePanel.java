package edu.ics111.h09;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Represents a DicePanel. Heavily based on textbooks 6.3 example so left author of textbook as one
 * of the authors of the code
 * 
 * @author David J. Eck
 * @author Austin Gardner
 */
public class DicePanel extends JPanel {

  /**
   * A main routine allows this class to be run as an application.
   * 
   */
  public static void main(String[] args) {
    JFrame window = new JFrame("Dice");
    DicePanel content = new DicePanel();
    window.setContentPane(content);
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.setLocation(120, 70);
    window.pack();
    window.setVisible(true);
  }

  GraphicalPairOfDice dice;

  /**
   * The constructor adds a mouse listener to the panel. The listener will roll the dice when the
   * user clicks the panel. Also, the background color and the preferred size of the panel are set.
   */
  public DicePanel() {
    dice = new GraphicalPairOfDice();
    setPreferredSize(new Dimension(100, 100));
    setBackground(new Color(200, 200, 255)); // light blue
    addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent evt) {
        dice.rollDice();
        repaint();
      }
    });
  }


  /**
   * The paintComponent method just draws the two dice and draws a one-pixel wide blue border around
   * the panel.
   * 
   * @param g The graphics context
   */
  public void paintComponent(Graphics g) {
    super.paintComponent(g); // fill with background color.
    Graphics2D g2 = (Graphics2D) g;
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g.setColor(Color.BLUE);
    g.drawRect(0, 0, 99, 99);
    g.drawRect(1, 1, 97, 97);
    dice.drawDie(g, 1, 10, 10);
    dice.drawDie(g, 2, 55, 55);
  }
}
