package edu.ics111.h03;

import java.util.Scanner;

/**
 * Represents a RollingAVariable.
 * 
 * @author Austin Gardner Used Chatgpt and Stack Overflow for help.
 *
 */
public class RollingAVariable {

  /**
   * Asks for an int between 2 and 12 and simulates rolling a dice until it hits that number, then
   * outputs the number of times rolled.
   * 
   * @param args Not used.
   */
  public static void main(String[] args) {
    rollVariableNumber();

  }


  /**
   * Asks for an int between 2 and 12 and simulates rolling a dice until it hits that number, then
   * outputs the number of times rolled.
   */
  public static void rollVariableNumber() {
    boolean keepRolling = true;
    int rollCount = 0;

    Scanner userInput = new Scanner(System.in);
    System.out.println("Input the number of faces for the dice (int only): ");
    if (userInput.hasNextInt()) {
      int targetRoll = userInput.nextInt();
      if (targetRoll < 2 || targetRoll > 12) {
        System.out.println("Please choose a number between 2 and 12");
        rollVariableNumber();
      } else {
        System.out.println("target: " + targetRoll);

        while (keepRolling) {
          rollCount++;
          int firstDieResult = (int) (Math.random() * 6) + 1;
          int secondDieResult = (int) (Math.random() * 6) + 1;
          int total = firstDieResult + secondDieResult;
          System.out.println(total);
          if (total == targetRoll) {
            keepRolling = false;
            System.out.println("It took " + rollCount + " rolls to hit " + targetRoll);
          }
        }
      }

    } else {
      System.out.println("Error because the the input wasn't an integer");
      rollVariableNumber();
    }

    userInput.close();
  }

}
