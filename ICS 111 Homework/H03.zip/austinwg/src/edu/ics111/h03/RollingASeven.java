package edu.ics111.h03;

/**
 * Represents a RollingASeven. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 * 
 *
 */
public class RollingASeven {

  /**
   * Checking how many rolls it takes to roll a 7.
   * 
   * @param args Not Used.
   */
  public static void main(String[] args) {

    boolean keepRolling = true;
    int rollCount = 0;

    while (keepRolling) {
      rollCount++;
      int firstDieResult = (int) (Math.random() * 6) + 1;
      int secondDieResult = (int) (Math.random() * 6) + 1;
      int total = firstDieResult + secondDieResult;
      System.out.println(total);
      if (total == 7) {
        keepRolling = false;
        System.out.println("It took " + rollCount + " rolls to hit 7");
      }
    }

  }

}
