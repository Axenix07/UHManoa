package edu.ics111.h11;

import java.util.Arrays;

/**
 * Represents a DynamicArrayOfStrings. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 */
public class DynamicArrayOfStrings implements ICS111List, Sortable {
  private String[] array;
  private int size;

  /**
   * Creates a new DynamicArrayOfStrings.
   *
   */
  public DynamicArrayOfStrings() {
    array = new String[10];
    size = 0;
  }


  /**
   * Gives the number of strings in the array.
   * 
   * @return the number of strings in the array.
   */
  public int size() {
    return size;
  }


  /**
   * Adds s to the end of the array. Returns true.
   * 
   * @param s The string getting added to the end of the array.
   * @return true
   */
  public boolean add(String s) {
    ensureCapacity();
    array[size++] = s;
    return true;
  }


  /**
   * Inserts s into position index.
   * 
   * @param index The position getting inserted into
   * @param s The string getting inserted.
   * @return True
   */
  public boolean add(int index, String s) {
    ensureCapacity();
    System.arraycopy(array, index, array, index + 1, size - index);
    array[index] = s;
    size++;
    return true;
  }


  /**
   * Returns the string at index.
   * 
   * @param index location of the string to be returned
   * @return Returns the string at index.
   */
  public String get(int index) {
    return array[index];
  }


  /**
   * Replaces the string at index with s. Returns old value.
   * 
   * @param index location of the string being replaced
   * @param s The string being added
   * @return the old value at the given index
   */
  public String set(int index, String s) {
    String old = array[index];
    array[index] = s;
    return old;
  }


  /**
   * Removes the string at index. Returns string.
   * 
   * @param index the location of the string being removed
   * @return Returns the value of the string being removed
   */
  public String remove(int index) {
    System.arraycopy(array, index + 1, array, index, size - index - 1);
    size--;
    array[size] = null;
    String removed = array[index];
    return removed;
  }


  /**
   * Removes string from the array, returns true if string was in the array.
   * 
   * @param s the string being removed
   * @return True if string was in array
   */
  public boolean remove(String s) {
    int index = indexOf(s);
    if (index != -1) {
      remove(index);
      return true;
    }
    return false;
  }


  /**
   * Returns the index of s or -1 if s is not in the array.
   * 
   * @param s The string being looked for.
   * @return The index of the string being looked for
   */
  public int indexOf(String s) {
    for (int i = 0; i < size; i++) {
      if (array[i].equals(s)) {
        return i;
      }
    }
    return -1;
  }


  /**
   * writes a string representation of the array.
   * 
   * @return Returns a string representation of the array.
   */
  public String toString() {
    return Arrays.toString(Arrays.copyOf(array, size));
  }


  /**
   * Sorts the array in increasing order.
   */
  public void sort() {
    for (int i = 1; i < size; i++) {
      String key = array[i];
      int j = i - 1;
      while (j >= 0 && array[j].compareTo(key) > 0) {
        array[j + 1] = array[j];
        j--;
      }
      array[j + 1] = key;
    }
  }


  /**
   * Method to make sure the length of the array is correct.
   */
  private void ensureCapacity() {
    if (size == array.length) {
      array = Arrays.copyOf(array, array.length * 2);
    }
  }
}