package edu.ics111.h11;

/**
 * Represents a Sortable. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 *
 */
public interface Sortable {
  /**
   * Sorts the array in increasing order.
   */
  void sort();
}
