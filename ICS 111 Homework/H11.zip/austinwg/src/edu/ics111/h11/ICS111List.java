package edu.ics111.h11;

/**
 * Represents a ICS111List. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 */
public interface ICS111List {
  /**
   * Gives the number of strings in the array.
   * 
   * @return the number of strings in the array.
   */
  int size();


  /**
   * Adds s to the end of the array. Returns true.
   * 
   * @param s The string getting added to the end of the array.
   * @return true
   */
  boolean add(String s);


  /**
   * Inserts s into position index.
   * 
   * @param index The position getting inserted into
   * @param s The string getting inserted.
   * @return True
   */
  boolean add(int index, String s);


  /**
   * Returns the string at index.
   * 
   * @param index location of the string to be returned
   * @return Returns the string at index.
   */
  String get(int index);


  /**
   * Replaces the string at index with s. Returns old value.
   * 
   * @param index location of the string being replaced
   * @param s The string being added
   * @return the old value at the given index
   */
  String set(int index, String s);


  /**
   * Removes the string at index. Returns string.
   * 
   * @param index the location of the string being removed
   * @return Returns the value of the string being removed
   */
  String remove(int index);


  /**
   * Removes string from the array, returns true if string was in the array.
   * 
   * @param s the string being removed
   * @return True if string was in array
   */
  boolean remove(String s);


  /**
   * Returns the index of s or -1 if s is not in the array.
   * 
   * @param s The string being looked for.
   * @return The index of the string being looked for
   */
  int indexOf(String s);


  /**
   * writes a string representation of the array.
   * 
   * @return Returns a string representation of the array.
   */
  String toString();
}
