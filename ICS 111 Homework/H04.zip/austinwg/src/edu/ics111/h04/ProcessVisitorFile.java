package edu.ics111.h04;

import edu.ics111.h02.TextIO;

/**
 * Represents a ProcessVisitorFile. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 * 
 *
 */
public class ProcessVisitorFile {

  /**
   * Processes a data file of visitor information.
   * 
   * @param args Not Used
   */
  public static void main(String[] args) {

    int visitors = 0;
    double spending = 0.0;
    int countryCount = 0;
    int noData = 0;

    TextIO.readFile("src//visitors.dat");

    while (!TextIO.eof()) {
      countryCount++;

      try {
        TextIO.getWord();
        visitors = visitors + TextIO.getInt();
        TextIO.getWord();
        spending = spending + TextIO.getlnDouble();

      } catch (Exception error) {
        noData++;
        TextIO.getlnString();
      }

    }

    double averageSpending = (Math.round((spending / visitors) * 100.00) / 100.00);

    System.out.println("Total Visitors: " + visitors);
    System.out.printf("Average spending per visitor: $" + "%.2f\n", averageSpending);
    System.out.printf("Total Spending: $" + "%.2f\n", spending);
    System.out.println("The number of countries with no data: " + noData);
    System.out.println("Number of Countries: " + countryCount);

  }

}
