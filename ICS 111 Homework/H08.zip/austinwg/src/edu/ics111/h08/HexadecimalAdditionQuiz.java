package edu.ics111.h08;

import edu.ics111.h02.TextIO;

/**
 * Represents a HexadecimalAdditionQuiz. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 *
 */
public class HexadecimalAdditionQuiz {

  /**
   * Administers a basic hexadecimal addition quiz to the user.
   * 
   * @param args Not Used
   */
  public static void main(String[] args) {
    administerQuiz(createQuiz());
  }


  /**
   * Creates an array with the objects for the 10 questions.
   * 
   * @return returns the array with the 10 question objects
   */
  public static HexAdditionQuestion[] createQuiz() {

    HexAdditionQuestion[] questions = new HexAdditionQuestion[10];

    for (int questionCount = 0; questionCount <= 9; questionCount++) {
      questions[questionCount] = new HexAdditionQuestion();
    }

    return questions;
  }


  /**
   * Administers and grades the quiz.
   * 
   * @param questions The array for the created list of questions
   */
  public static void administerQuiz(HexAdditionQuestion[] questions) {

    String[] answers = new String[10];
    int correctAnswerCount = 0;

    for (int questionCount = 0; questionCount < questions.length; questionCount++) {
      System.out.println(questions[questionCount].getQuestion());
      answers[questionCount] = TextIO.getlnString();
    }

    for (int questionCount = 0; questionCount < questions.length; questionCount++) {

      if (questions[questionCount].correctAnswerAsHex().equals(answers[questionCount])) {
        System.out.println(
            questions[questionCount].getQuestion() + " " + answers[questionCount] + " (Correct)");
        correctAnswerCount++;
      } else {
        System.out.println(questions[questionCount].getQuestion() + " " + answers[questionCount]
            + " (Incorrect) The correct answer is "
            + questions[questionCount].correctAnswerAsHex());
      }
    }

    System.out.printf("Score %d/100", (correctAnswerCount * 10));
  }
}