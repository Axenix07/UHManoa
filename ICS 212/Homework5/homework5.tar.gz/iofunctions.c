/*****************************************************************
/  NAME:        Austin Gardner
/
//  HOMEWORK:    5
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        Oct 8, 2025
//
//  FILE:        iofunction.c
//
//  DESCRIPTION:
//   This file contains the driver and the user-interface functions
//   for Homework 1 - the temperature conversion program
//
//
//  ****************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include "pokemon.h"
#include "iofunctions.h"

/*
 * Function Name: writefile
 * Description: Writes a list of pokemon to a file
 * Parameters: pokearray (the list of pokemon being written), num (the size of the array), filename (the name of the file being written to
 * Return Value: 0 if no errors, otherwise -1
 */

int writefile( struct pokemon pokearray[], int num, char filename[] )
{
    FILE *file;
    int error;
    int i;

    i = 0;
    error = 0;

    file = fopen(filename, "w");

    if (file == NULL)
    {
        error = -1;
    }

    while(i < num)
    {
        fprintf(file, "%d\n", pokearray[i].level);
        fprintf(file, "%s\n", pokearray[i].name);
        i++;
    }

    fclose(file);

    return error;
}

/*
 * Function Name: readfile
 * Description: Reads a list of pokemon from a file and stores it in an array
 * Parameters: pokearray (The array the pokemon are being stored in), num (pointer to the size of the array), filename (name of the file being read from
 * Return Value: 0 if no errors, otherwise -1
 */

int readfile( struct pokemon pokearray[], int* num, char filename[] )
{
    FILE *file;
    int error;
    int count;
    char level[10];
    int stop;

    stop = 0;
    error = 0;
    file = fopen(filename, "r");

    if (file == NULL) {
        error = -1;
    }

    count = 0;
    while( error == 0 && stop == 0 && count < *num )

    {
        if (fgets(level, 10, file) == NULL)
        {
            stop = 1;
        }
        if (stop == 0)
        {
            pokearray[count].level = atoi(level);

            fgets(pokearray[count].name, 25, file);
            pokearray[count].name[strlen(pokearray[count].name) - 1] = '\0';

            count++;
        }
    }

    *num = count;

    if (error == 0)
    {
        fclose(file);
    }

    return error;
}
