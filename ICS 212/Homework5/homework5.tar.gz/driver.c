/*****************************************************************
*  NAME:  Austin Gardner

//  HOMEWORK:    5
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        Oct 8, 2025
//
//  FILE:        driver.c
//
//  DESCRIPTION:
//   This file contains the testing for readfile and writefile functions in iofunctions.c
****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "pokemon.h"
#include "iofunctions.h"

/*
 * Function Name: Main
 * Description: The test functions for iofunctions.c
 * Parameters: argc (number of arguments passed), argv (array of string arguments passed)
 * Return Value: It worked :)
 */

int main(int argc, char* argv[])
{
    struct pokemon pokearray1[] = {
        {10, "Pikachu"},
        {5, "Bulbasaur"},
        {15, "Charmander"},
        {8, "Squirtle"}
    };
    struct pokemon pokearray2[4] = {0};
    struct pokemon pokearray3[2] = {0};
    int size2;
    int size3;
    int test1;
    int test2;
    int test3;
    int test4;
    int i;

    printf("Calling the writefile function to test1.txt\n");

    test1 = writefile(pokearray1, 4, "test1.txt");
    if (test1 == 0)
    {
        printf("No errors returned from writefile.\n");
    }
    else if (test1 == -1)
    {
        printf("Error returned from writefile.\n");
    }
    else
    {
        printf("Mystery third value reached somehow.\n");
    }

    printf("Running readfile to empty array from test1.txt\n");

    size2 = 4;
    test2 = readfile(pokearray2, &size2, "test1.txt");

    if (test2 == 0)
    {
        printf("No errors returned from readfile.\n");
    }
    else if (test2 == -1)
    {
        printf("Error returned from readfile.\n");
    }
    else
    {
        printf("Mystery third value reached somehow.\n");
    }

    printf("Printing filled values of array 2.\n");
    for (i = 0; i < size2; i++)
    {
        printf("Level: %d, Name: %s\n", pokearray2[i].level, pokearray2[i].name);
    }

    printf("Reading from test1.txt to an array of length 2\n");
    size3 = 2;
    test3  = readfile(pokearray3, &size3, "test1.txt");

    if (test3 == 0)
    {
        printf("No errors returned from readfile.\n");
    }
    else if (test3 == -1)
    {
        printf("Error returned from readfile.\n");
    }
    else
    {
        printf("Mystery third value reached somehow.\n");
    }

    printf("Printing filled values of array 3.\n");
    for (i = 0; i < size3; i++)
    {
        printf("Level: %d, Name: %s\n", pokearray3[i].level, pokearray3[i].name);
    }

    printf("Testing reading from a file that doesn't exist.\n");
    test4 = readfile(pokearray2, &size2, "JazzHands.txt");
    if (test4 == 0)
    {
        printf("No errors returned from readfile.\n");
    }
    else if (test4 == -1)
    {
        printf("Error returned from readfile.\n");
    }
    else
    {
        printf("Mystery third value reached somehow.\n");
    }

    return 0;
}
