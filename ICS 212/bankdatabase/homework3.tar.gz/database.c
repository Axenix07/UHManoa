#include <stdio.h>

int addRecord(struct record ** record, int accountNumber, char *name, char *address)
{
    extern int debugMode;

    if (debugMode == 1)
    {
        printf("addRecord\n");
        printf("accountNumber: %d, name: %s, address: %s\n", accountNumber, name, address);
    }
}
void printAllRecords(struct record * record)
{
    extern int debugMode;

    if (debugMode == 1)
    {
        printf("printAllRecords\n");
    }
}
int findRecord(struct record * record, int accountNumber)
{
    extern int debugMode;

    if (debugMode == 1)
    {
        printf("findRecord\n");
        printf("accountNumber: %d\n", accountNumber);
    }
}
int deleteRecord(struct record ** record, int accountNumber)
{
    extern int debugMode;

    if (debugMode == 1)
    {
        printf("deleteRecord\n");
        printf("accountNumber: %d\n", accountNumber);
    }
}
