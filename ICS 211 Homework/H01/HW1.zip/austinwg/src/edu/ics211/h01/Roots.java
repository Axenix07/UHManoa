package edu.ics211.h01;

/**
 * Represents a Roots. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 *
 */
public class Roots {

  /**
   * outputs an array with the square roots from 2 to a given maximum.
   * 
   * @param max The maximum value to get a square root from
   * @return An array with the results of the square roots from 2 to the max parameter
   * @exception IllegalArgumentException for if the passed parameter is less than 2.
   */
  public static double[] roots(int max) {

    if (max < 2) {
      throw new IllegalArgumentException("Parameter must be 2 or greater.");
    } else {

      double[] results = new double[max - 1];
      for (int i = 2; i <= max; i++) {
        results[i - 2] = Math.sqrt(i);
      }

      return results;

    }
  }

}
