package edu.ics211.h01;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Represents a Reader. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 *
 */
public class Reader {

  /**
   * Reads a file and outputs the number of characters in the file.
   * 
   * @param fileName name of the file being read.
   * @return an Int with the number of characters in the file.
   */
  public static int numChars(String fileName) {
    int charCount = 0;

    try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
      while ((reader.read()) != -1) {
        charCount++;
      }
    } catch (IOException e) {
      System.out.println("Error reading the file: " + e.getMessage());
    }

    return charCount;
  }

}
