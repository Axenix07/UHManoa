package edu.ics211.h01;

import java.io.File;
import java.util.Random;

/**
 * Represents a HW1. Used Chatgpt and Stack Overflow for help.
 * 
 * @author Austin Gardner
 *
 */
public class HW1 {

  /**
   * Runs roots with a random number between 0-10 and reads the files and outputs the number of
   * characters.
   * 
   * @param args The names of the files.
   */
  public static void main(String[] args) {
    Random random = new Random();
    int randomInt = random.nextInt(11);

    try {
      double[] results = Roots.roots(randomInt);
      for (int i = 0; i < results.length; i++) {
        System.out.print(results[i]);
        if (i < results.length - 1) {
          System.out.print(", ");
        }
      }
      System.out.println();
    } catch (IllegalArgumentException e) {
      System.out.println("Error: " + e.getMessage());
    }

    for (String fileName : args) {
      File file = new File(fileName);
      if (!file.exists()) {
        System.out.println(fileName + " not found");
      } else {
        int numCharacters = Reader.numChars(fileName);
        if (numCharacters != -1) {
          System.out.println(fileName + " " + numCharacters);
        } else {
          System.out.println(fileName + " not found");
        }
      }

    }
  }

}
